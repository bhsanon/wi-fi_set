[INSTALAÇÃO]

#Wi-Fi_set Router Social Engineering Toolkit v2017.1 - By 845 AN0N [Skull_Hunters] [youtube.com/c/SkullHunters]"
#Modificações são permitidas desde que se mantennham os créditos ao autor original.
#Baseado no Linset 0.14 rev 35 By vk496 & Fluxion 0.1 By Deltaxflux
#Baseado no AIRSET 2016.11 by Alef Carvalho

0 - Baixe o wi-fi_set no site www.skullhunters.esy.es

1 - Adicionar permissoes nos arquivos: 
abra um terminal e digite chmod -R 777 airset


2 - Instalar as dependências:
abra um terminal no diretório da pasta e rode o comando ./wi-fi_set
ele vai mostrar as dependências a instalar para rodar o programa.

3- Rodar novamente o ./wi-fi_set e proceder com o ataque como no tutorial:
www.youtube.com/c/SkullHunters

[AVISOS]

O redirecionamento não funciona para páginas https
Em algumas versões do wifislax não está derrubando a página fake (teste todas as opções de desautenticação do programa, provavelmente uma vai funcionar)

--------------------------------------- ATENÇÃO ------------------------------------------------
Essa ferramenta foi criada com o objetivo de testar a segurança de redes wi-fi, no vídeo testo a mesma em uma rede de minha propriedade é em ambiente controlado. não sou responsável por qualquer tipo de mal uso que você fizer dela.


[LINKS]
www.youtube.com/c/SkullHunters

