#!/usr/bin/python

#Wi-Fi_set Router Social Engineering Toolkit v2017.1 - By 845 AN0N [Skull_Hunters] [youtube.com/c/SkullHunters]"
#Modificações são permitidas desde que se mantennham os créditos ao autor original.
#Baseado no Linset 0.14 rev 35 By vk496 & Fluxion 0.1 By Deltaxflux
#Baseado no AIRSET 2016.11 by Alef Carvalho

from os import system

commands = [
    "apt-key adv --keyserver pgp.mit.edu --recv-keys ED444FF07D8D0BF6",
    "echo '# Kali linux repositories",
    "deb http://http.kali.org/kali kali-rolling main contrib non-free",
    "deb http://repo.kali.org/kali kali-bleeding-edge main' >> /etc/apt/sources.list",
    "apt-get update -m"
]

for i in commands:
    system(i)
